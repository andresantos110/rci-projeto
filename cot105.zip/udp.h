#include <arpa/inet.h>

int commUDP(char mensagem[], char buffer[], char regIP[], char regUDP[]);