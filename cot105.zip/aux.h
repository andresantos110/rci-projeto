void findNode(char buffer[], char line[], int nNodes, char node []);

int max3(int a, int b, int c);

int initNode(struct node *nodo);

int updateTable(char origem[], char dest[], struct node *nodo);
